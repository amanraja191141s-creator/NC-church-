import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(p, 'utf8');

test('Tools menu opens with no Quick Access section and collapsed search field', () => {
  const html = read('index.html');
  const start = html.indexOf('id="screen-tools"');
  const end = html.indexOf('id="screen-favorites"', start);
  const tools = html.slice(start, end);
  assert.ok(start >= 0 && end > start);
  assert.doesNotMatch(tools, /Quick Access|Quick actions|quick-access/i);
  assert.match(tools, /id="tools-search-panel" hidden/);
  assert.match(html, /id="btn-tools-search"[^>]*aria-expanded="false"[^>]*aria-controls="tools-search-panel"/);
});

test('all 18 premium menu cards exist once and link to their existing screen IDs', () => {
  const html = read('index.html');
  const start = html.indexOf('id="premium-tools-grid"');
  const end = html.indexOf('</div>', start);
  const grid = html.slice(start, end);
  const ids = [...grid.matchAll(/data-tool-screen="([a-z]+)"/g)].map(m => m[1]);
  assert.equal(ids.length, 18);
  assert.equal(new Set(ids).size, 18);
  for (const id of ids) assert.match(html, new RegExp(`id="screen-${id}"`), `missing screen ${id}`);
});

test('header search toggles visibility accessibly and Escape closes the panel', () => {
  const js = read('assets/js/app.js');
  assert.match(js, /const opening = panel\.hidden/);
  assert.match(js, /button\.setAttribute\('aria-expanded', String\(opening\)\)/);
  assert.match(js, /event\.key === 'Escape'[\s\S]*panel\.hidden = true/);
  assert.match(js, /button\?\.focus\(\{ preventScroll: true \}\)/);
});

test('new premium menu CSS is compiled into Android web bundle and cache-busted', () => {
  const html = read('index.html');
  const builder = read('scripts/prepare-android-web.mjs');
  const css = read('assets/css/app.css');
  const sw = read('service-worker.js');
  assert.match(html, /rebuild-v98\.44\.css/);
  assert.match(builder, /rebuild-v98\.44\.css/);
  assert.match(css, /match approved premium Tools reference/);
  assert.match(sw, /sa-calculator-v98-44-premium-tools-screen/);
});

test('release identity is synchronized across package, manifest and workflow', () => {
  const pkg = JSON.parse(read('package.json'));
  const manifest = JSON.parse(read('manifest.webmanifest'));
  const workflow = read('.github/workflows/main.yml');
  assert.equal(pkg.version, '1.98.44-v98.44');
  assert.equal(manifest.version, '1.98.44-v98.44');
  assert.match(workflow, /1\.98\.44-v98\.44/);
  assert.match(workflow, /1098044/);
});
