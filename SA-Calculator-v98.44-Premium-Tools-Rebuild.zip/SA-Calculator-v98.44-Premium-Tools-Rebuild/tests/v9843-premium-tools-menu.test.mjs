import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(p, 'utf8');

test('v98.44 replaces the old drawer tools menu with a dedicated premium Tools screen', () => {
  const html = read('index.html');
  assert.match(html, /id="screen-tools"[^>]*aria-label="Tools"/);
  const drawer = html.slice(html.indexOf('<aside id="sidebar-drawer"'), html.indexOf('</aside>'));
  assert.doesNotMatch(drawer, /Quick access|drawer-category|drawer-tool-search|All tools/);
  assert.match(html, /class="premium-tools-grid" id="premium-tools-grid"/);
});

test('the premium grid exposes all 18 expected destinations exactly once and all resolve to real screens', () => {
  const html = read('index.html');
  const grid = html.slice(html.indexOf('id="premium-tools-grid"'), html.indexOf('</div>', html.indexOf('id="premium-tools-grid"')));
  const ids = [...grid.matchAll(/data-tool-screen="([a-z]+)"/g)].map(m => m[1]);
  assert.equal(ids.length, 18);
  assert.equal(new Set(ids).size, 18);
  for (const id of ids) assert.match(html, new RegExp(`id="screen-${id}"`), `missing screen ${id}`);
  for (const label of ['Calculator','Currency Converter','Unit Converter','Discount','Percentage','Sales Tax','Body Metrics','Date Calculator','Fuel Cost','Fuel Efficiency','Grade Average','Hex Converter','Loan Calculator','Savings Calculator','Tip Calculator','Unit Price','World Time','Settings']) assert.ok(grid.includes(`>${label}<`), `missing card label ${label}`);
});

test('Tools bottom navigation opens the dedicated screen; History is a separate bottom item', () => {
  const html = read('index.html');
  const js = read('assets/js/app.js');
  assert.match(html, /data-bottom-nav="history"/);
  assert.match(html, /data-bottom-nav="tools"/);
  assert.match(js, /if \(target === 'tools'\) \{ switchScreen\('tools'\); return; \}/);
  assert.match(js, /if \(target === 'history'\).*btn-history-open/s);
  assert.match(js, /data-tool-screen/);
  assert.match(js, /tools-screen-search/);
});

test('Tools keeps the SA Calculator brand header and activates the Tools tab without injecting a duplicate toolbar', () => {
  const js = read('assets/js/app.js');
  assert.match(js, /screenId === 'calc' \|\| screenId === 'tools' \? 'SA Calculator' : translatedTitle/);
  assert.match(js, /screenId !== 'calc' && screenId !== 'tools'/);
  assert.match(js, /classList.toggle\('tools-screen-active', screenId === 'tools'\)/);
  assert.match(read('index.html'), /id="btn-tools-search"/);
  assert.match(read('index.html'), /id="btn-tools-more"/);
  assert.match(js, /screenId === 'settings' \|\| screenId === 'tools' \? 'tools'/);
});

test('premium Tools screen CSS is part of the Android production bundle and offline cache release', () => {
  const html = read('index.html');
  const builder = read('scripts/prepare-android-web.mjs');
  const sw = read('service-worker.js');
  assert.match(html, /rebuild-v98\.44\.css/);
  assert.match(builder, /rebuild-v98\.44\.css/);
  assert.match(sw, /sa-calculator-v98-44-premium-tools-screen/);
});

test('v98.44 release identity and downloadable workflow are synchronized', () => {
  const pkg = JSON.parse(read('package.json'));
  assert.equal(pkg.version, '1.98.44-v98.44');
  const workflow = read('.github/workflows/main.yml');
  assert.equal(workflow, read('SA-Calculator-v98.44-Android-Workflow.yml'));
  assert.match(workflow, /1098044/);
});
