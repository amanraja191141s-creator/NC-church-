import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),"..");
const read=p=>fs.readFileSync(path.join(root,p),"utf8");
const css=read("assets/css/rebuild-v98.35.css");
const html=read("index.html");
const pkg=JSON.parse(read("package.json"));
test("v98.35 touch-focus fix hides the skip-link ghost while keyboard focus remains visible",()=>{
 assert.match(css,/\.skip-to-workspace:focus \{[^}]*opacity:0 !important/);
 assert.match(css,/\.skip-to-workspace:focus-visible \{[^}]*opacity:1 !important/);
 assert.match(css,/focus:not\(:focus-visible\)/);
 assert.match(html,/href="#screen-viewport"/);
});
test("v98.44 premium Tools screen includes every declared destination exactly once",()=>{
 const cards=[...html.matchAll(/class="premium-tool-card"[^>]*data-tool-screen="([^"]+)"|data-tool-screen="([^"]+)"/g)].map(m=>m[1]||m[2]);
 const expected=['calc','currencies','units','discount','percent','salestax','bodymetrics','date','fuelcost','fuelefficiency','gradeavg','hex','loan','savings','tip','unitprice','worldtime','settings'];
 assert.equal(cards.length,18); assert.deepEqual([...cards].sort(),[...expected].sort());
 assert.match(html,/id="tools-screen-search"/); assert.match(html,/id="screen-tools"/);
 assert.doesNotMatch(html.slice(html.indexOf('id="sidebar-drawer"'),html.indexOf('</aside>')),/Quick access|drawer-category/);
});
test("v98.44 dedicated Tools screen has responsive premium card styling",()=>{
 const premium=read("assets/css/rebuild-v98.44.css");
 assert.match(premium,/\.premium-tools-grid/); assert.match(premium,/grid-template-columns: repeat\(2, minmax\(0, 1fr\)\)/);
 assert.match(premium,/max-width: 360px/); assert.match(premium,/prefers-reduced-motion/);
});

test("v98.35 release identity is synchronized",()=>{assert.equal(pkg.version,"1.98.44-v98.44");});
