# SA Calculator v98.44 — Consolidated premium release

## What changed in v98.44
- Consolidated the existing production CSS cascade into one generated `assets/css/app.css` file. The original source layers remain in `assets/css/` for maintainability and reproducible builds.
- The HTML now loads one production stylesheet instead of ten separate source layers, reducing render-blocking stylesheet requests while preserving source order and styling rules.
- The Android web-bundle builder regenerates the consolidated stylesheet from the source layers before copying assets.
- The service worker precaches the consolidated stylesheet rather than caching unused individual CSS layers.
- Corrected release identity to `1.98.44-v98.44` / Android versionCode `1098044`.
- Removed obsolete duplicate root workflow files. One active GitHub Actions workflow remains at `.github/workflows/main.yml`; the downloadable standalone copy is `SA-Calculator-v98.44-Android-Workflow.yml`.
- Replaced the old drawer-based Quick Access/categorized Tools menu with a dedicated searchable 18-card Tools screen matching the supplied design reference.
- Added a Tools-only header Search action and More action, matching the supplied visual reference.
- Updated bottom navigation to Calculator, History, Favorites and Tools; Settings is a card in the Tools grid and remains available from the compact utility drawer.
- Kept the compact drawer for Help, Scientific Calculator, History and Settings only; removed the duplicated old tool directory.
- Preserved existing calculator logic, all 16 dedicated tool routes, converter behavior, themes, settings, history, favorites and scientific dialog behavior.

## Build and test
- `npm test` runs the complete Node regression suite.
- `npm run build:web` regenerates the single CSS bundle and prepares the Capacitor web root.
- `npm run android:apk` builds a debug APK when Android SDK/Gradle prerequisites are available.

## Validation limits
Automated tests and source/bundle checks do not replace hosted GitHub Actions execution, real Android installation, screenshot comparison, touch-latency measurement, memory profiling or long-session device testing. The supplied Tools-menu design has been implemented in the actual source UI; a physical Android screenshot comparison is still required. The older 18-screen visual collage remains a design guide, not a screenshot captured from a running APK.
